package com.example.pageview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

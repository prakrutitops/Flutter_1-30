import "package:flutter/material.dart";


void main() {

	runApp(
		Center(
			child: Text(
				"Hello Flutter",
				textDirection: TextDirection.ltr
		  ),
		)
	);
}
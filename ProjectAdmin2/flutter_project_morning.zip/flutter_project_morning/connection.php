<?php
    define('HOST','localhost');
    define('USER','id21554504_tops');
    define('DB','id21554504_practice');
    define('PASS','Tops?123');
    
    $con=mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');
?>